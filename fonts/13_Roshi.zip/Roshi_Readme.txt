Unrender Font Foundry
All Files included are Copyright 1999 Zane Townsend.

Web Site:  http://www.Unrender.com
Email:    ztownsend@hotmail.com
______________________________________________________________________________

13_Roshi.ttf

Revision notes:  3rd release, compleatly redesigned from scratch.

Special character notes:  None.

Other Notes: "Roshi: a venerable teacher, whether a monk or layperson, woman or man"

______________________________________________________________________________